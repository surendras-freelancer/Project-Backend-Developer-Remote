<?php

namespace App\Service;

use App\Rabbit\MessagingProducer;
use Symfony\Component\HttpFoundation\JsonResponse;


class MessageService
{
    private $messagingProducer;

    public function __construct(MessagingProducer $messagingProducer)
    {
        $this->messagingProducer = $messagingProducer;
    }

    public function createMessage(int $numberOfUsers): JsonResponse
    {

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://highload.today/category/novosti/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST'
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        sleep(2);

        preg_match('/<script(.*)>(.*)var stick = (.*);(.*)var current_page = (.*);(.*)var max_pages = (.*);(.*)<\/script>/isU',$response,$newsdetails);

        for ($i=50; $i>=0; $i--) {
            $message = json_encode([
                'stick' => $newsdetails[3],
                'current_page' => $i,
                'max_pages' => $newsdetails[7],
            ]);

            $this->messagingProducer->publish($message);
        }

        return new JsonResponse(['status' => 'Sent!']);
    }
}