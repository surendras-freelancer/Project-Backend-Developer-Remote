<?php

namespace App\Rabbit;

use Symfony\Component\HttpFoundation\JsonResponse;

class MessagingProducer extends \OldSound\RabbitMqBundle\RabbitMq\Producer
{
}