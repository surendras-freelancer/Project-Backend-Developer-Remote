<?php

namespace App\Rabbit;

use OldSound\RabbitMqBundle\RabbitMq\ConsumerInterface;
use PhpAmqpLib\Message\AMQPMessage;
use App\Controller\ApiController; 
use Doctrine\Persistence\ManagerRegistry;



class MessageConsumer implements ConsumerInterface
{
    private $doctrine;

    public function __construct(MessagingProducer $messagingProducer,ManagerRegistry $doctrine)
    {
        $this->messagingProducer = $messagingProducer;
        $this->doctrine = $doctrine;
    }

    public function execute(AMQPMessage $msg)
    {        
        $message = json_decode($msg->body, true);
        echo 'Received a message from '.$message['current_page']." && ";

        $api_controller = new ApiController;
        echo $api_controller->fetch_news($message['stick'],$message['current_page'],$message['max_pages'],$this->doctrine);
        
    }
}