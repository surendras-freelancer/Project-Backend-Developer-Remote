<?php

namespace App\Controller;

use App\Entity\News;
use App\Repository\NewsRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;


class ApiController extends AbstractController
{
    /**
     * @Route("/api/fetch_news/{stick}/{current_page}/{max_pages}", name="app_api")
     */
    public function fetch_news($stick,$current_page,$max_pages,ManagerRegistry $doctrine): JsonResponse
    {
        $response="";  
        $newsdetails=array();
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://highload.today/wp-content/themes/supermc/ajax/loadarchive.php',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('stick' => $stick,'page' => $current_page,'max_pages' => $max_pages,'cat' => '537'),
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        if($response!=''){
            preg_match_all('/<div class="lenta-item">(.*)<span class="meta-datetime"(.*)>(.*)<\/span>(.*)<a(.*)>(.*)<h2>(.*)<\/h2>(.*)<\/a>(.*)<div class="lenta-image">(.*)<img(.*)src="(.*)"(.*)>(.*)<\/a>(.*)<p>(.*)<\/p>(.*)<\/div>/isU',$response,$newsdetails);
            if(isset($newsdetails[3]) && count($newsdetails[3]) > 0){
                for($i=0;$i<count($newsdetails[3]);$i++){
                    $time   = trim($newsdetails[3][$i]); 
                    $title  = trim($newsdetails[7][$i]);
                    $imgsrc = trim($newsdetails[12][$i]);
                    $desc   = trim($newsdetails[16][$i]);

                    //check new with title exist or not
                    $news = $doctrine->getRepository(News::class)->findByTitle( $title);
                    $dateImmutable = new \DateTime("now"); 

                    if($news[0][1]>0){
                        $entityManager = $doctrine->getManager();
                        $single_news = $doctrine->getRepository(News::class)->findBy(["title" => $title]);

                        if (!$single_news[0]) {}
                        else{ //update news with date modified
                            $single_news[0]->setTitle($title);
                            $single_news[0]->setDescription($desc);
                            $single_news[0]->setImg($imgsrc);
                            $single_news[0]->setTiming($time);
                            $single_news[0]->setDateModified($dateImmutable);
                            $entityManager->flush();
                        }
                    }else{ //insert new news 
                        $entityManager = $doctrine->getManager();
                        $newsObject = new News();
                        $newsObject->setTitle($title);
                        $newsObject->setDescription($desc);
                        $newsObject->setImg($imgsrc);
                        $newsObject->setTiming($time);
                        $newsObject->setDateCreated($dateImmutable);
                        $newsObject->setDateModified($dateImmutable);
                        $entityManager->persist($newsObject);
                        $entityManager->flush();
                    }
                }
            }
        }
        return new JsonResponse(['current_page' => $current_page,'stick' => $stick]);
    }
}
