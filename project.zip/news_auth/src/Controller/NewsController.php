<?php

namespace App\Controller;

use App\Entity\News;
use App\Repository\NewsRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Session\SessionInterface;



class NewsController extends AbstractController
{

    /**
     * @Route("/news/{start}", name="shownews")
     */
    public function shownews(ManagerRegistry $doctrine,SessionInterface $session,$start): Response
    {
        
        if(!$session->has('login_username')){
            return $this->redirectToRoute('app_login');
        }
        if(strpos($session->get('login_roles'),'ROLE_ADMIN') === false){
            $adminuser = false;
        }else{
            $adminuser = true;
        }
        $total_list = 10;
        $offset = $start;
        $next = $start + 1;
        $start = ($start-1)* $total_list;
        
        
        $news = $doctrine->getRepository(News::class)->findAllWithLimit($start,$total_list);
        $total_news_count = $doctrine->getRepository(News::class)->fetchTotalCount();
        $lastpage = isset($total_news_count[0][1]) ? round($total_news_count[0][1]/$total_list) : '1';
        //$news = $doctrine->getRepository('News:class');
        return $this->render('news/index.html.twig',['adminuser' => $adminuser,'news' => $news,'next' => $next,'start'=>$offset,'lastpage'=>$lastpage]);
    }

    /**
     * @Route("/news", name="showdefault")
     */
    public function show(ManagerRegistry $doctrine,SessionInterface $session): Response
    {
        if(!$session->has('login_username')){
            return $this->redirectToRoute('app_login');
        }
        if(strpos($session->get('login_roles'),'ROLE_ADMIN') === false){
            $adminuser = false;
        }else{
            $adminuser = true;
        }

        $total_list = 10;
        $news = $doctrine->getRepository(News::class)->findAllWithLimit(0,$total_list);
        $total_news_count = $doctrine->getRepository(News::class)->fetchTotalCount();

        $lastpage = isset($total_news_count[0][1]) ? round($total_news_count[0][1]/$total_list) : '1';

        return $this->render('news/index.html.twig',['adminuser' => $adminuser,'news' => $news,'next' => 2,'start'=>0,'lastpage'=>$lastpage]);
    }

    /**
     * @Route("/news_delete/{id}", name="news_delete")
     */
    public function news_delete(ManagerRegistry $doctrine,SessionInterface $session,$id): Response
    {        
        if(!$session->has('login_username')){
            return $this->redirectToRoute('app_login');
        }
        if(strpos($session->get('login_roles'),'ROLE_ADMIN') === false){
            return $this->redirectToRoute('showdefault');
        }

        $single_news = $doctrine->getRepository(News::class)->find($id);
        
        if($single_news){
            $doctrine->getRepository(News::class)->remove($single_news,true);
            $error = false;
            $this->addFlash(
                'success',
                'Deleted successully.'
            );  

            $pagination = floor($id/10);
            if($pagination<=0){
                $pagination = 1;
            }
            
            return $this->redirectToRoute('shownews', ['start'=>$pagination]);
        }else{
            $error = "Invalid Entry. Please try again.";        
            return $this->render('news/success.html.twig',["error"=> $error]);
        }
    }
    
}
