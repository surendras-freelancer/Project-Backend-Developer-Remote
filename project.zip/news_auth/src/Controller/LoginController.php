<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;
use App\Entity\User;
use App\Repository\UserRepository;
use Symfony\Component\HttpFoundation\Session\SessionInterface;



class LoginController extends AbstractController
{
    /**
     * @Route("/", name="app_login")
     */
    public function index(AuthenticationUtils $authenticationUtils,SessionInterface $session): Response
    {
        // get the login error if there is one

        if($session->has('login_username')){
            return $this->redirectToRoute('showdefault');
        }

        $error = $authenticationUtils->getLastAuthenticationError();

        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();
       
        return $this->render('login/index.html.twig', [
            'controller_name' => 'LoginController',
            'error'         => $error,
        ]);
    }

    /**
     * @Route("/checklogin", name="checklogin")
     */
    public function checklogin(ManagerRegistry $doctrine,SessionInterface $session,Request $request): Response{
        if($session->has('login_username')){
            return $this->redirectToRoute('showdefault');
        }

        $username = $request->get('_username');
        $password = $request->get('_password');

        $submittedToken = $request->request->get('_csrf_token');

        if (!$this->isCsrfTokenValid('authenticate', $submittedToken)) {
            return $this->render('login/index.html.twig', [
                'controller_name' => 'LoginController',
                'error'         => "Invalid Entry. Please try again.",
            ]);
        }else{       

            $username = stripslashes($username);
            $password = stripslashes($password);

            $news = $doctrine->getRepository(User::class)->checkUserLogin($username,$password);
            if(count($news) == '0'){
                return $this->render('login/index.html.twig', [
                    'controller_name' => 'LoginController',
                    'error'         => "Invalid Credentials",
                ]);
            }else{
                $session->set('login_username', $username);
                $session->set('login_roles', $news[0]['roles']);
                $this->addFlash(
                    'success',
                    'Logged in successfully.'
                );  
                return $this->redirectToRoute('showdefault');
            }
        }
    }

    /**
     * @Route("/logout", name="app_logout")
     */
    public function logout(AuthenticationUtils $authenticationUtils,SessionInterface $session): Response
    {
        // get the login error if there is one

        $session->clear();
       
        return $this->render('login/index.html.twig', [
            'controller_name' => 'LoginController',
           'error'         => "You have been successfully logged out.",
        ]);
    }
}
